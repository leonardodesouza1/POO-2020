class Main {
  public static void main(String[] args) {
    int a [] [] = { {1,2}  , {3,4} };
    int b [] [] = { {-1,3} ,  {4,2} };
    int ab [] [] = new int [2] [2]; 
    for (int i = 0;i < a.length;i++){
      for (int j = 0; j < a[i].length;j++){
        for (int z = 0;z < a[j].length;z++){
          ab [i] [j] += a [i] [z] * b [z] [j];
        }
  }
  System.out.println();
  }
  for (int i = 0;i < a.length;i++){
      for (int j = 0; j < a[i].length;j++){
        System.out.print(ab[i] [j]+" ");
      }
      System.out.println();
  }
  }
}

