import java.util.Scanner;
import java.lang.Math;
class Main {
  public static double CalculoCilindro(double r,double h){
    double areabase = Math.PI * (r * r);
    double res = areabase * h;
    return res;
  }
  public static double CalculoEsfera(double r){
    double volume = (4 * Math.PI * (r * r * r)) / 3;
    return volume;
  }
  public static void main(String[] args) {
    Scanner leitor = new Scanner(System.in);
    int opcao = 0;
    double arestaarea,resareacubo,raio,resareaesfera,arestacubo,rescubo,raiocilindro,hcilindro,raioesfera;
    do{
      System.out.println("------------------------------------------ ");
      System.out.println("Digite opção 1 para area do cubo ");
      System.out.println("Digite opção 2 para area do esfera ");
      System.out.println("Digite opção 3 para volume do cubo ");
      System.out.println("Digite opção 4 para volume de cilindro ");
      System.out.println("Digite opção 5 para volume da esfera ");
      System.out.println("Digite opção 6 para Sair ");
      System.out.println("------------------------------------------ ");
      System.out.print("Opção: ");
      opcao = leitor.nextInt();
    }while(opcao <= 0 || opcao > 6 );
    if(opcao == 1){
      System.out.println("------------------------------------------ ");
      System.out.print("Digite o tamanho da aresta do cubo: ");
      arestaarea = leitor.nextDouble();
      resareacubo = (arestaarea * arestaarea) * 6;
      System.out.println("A area total do cubo é "+resareacubo);
      System.out.println("------------------------------------------ ");
    }
    if(opcao == 2){
      System.out.println("------------------------------------------ ");
      System.out.print("Digite o raio da esfera: ");
      raio = leitor.nextDouble();
      resareaesfera = 4 * Math.PI * (raio *raio);
      System.out.println("A area total da esfera é "+resareaesfera);
      System.out.println("------------------------------------------ ");
    }
    if(opcao == 3){
      System.out.println("------------------------------------------ ");
      System.out.print("Digite o tamanho da aresta do cubo: ");
      arestacubo = leitor.nextDouble();
      rescubo = (arestacubo * arestacubo) * arestacubo;
      System.out.println("O volume do cubo é "+rescubo);
      System.out.println("------------------------------------------ ");
    }
    if(opcao == 4){
      System.out.println("------------------------------------------ ");
      System.out.print("Digite o raio do cilindro: ");
      raiocilindro = leitor.nextDouble();
      System.out.print("Digite a altura do cilindro: ");
      hcilindro = leitor.nextDouble();
      System.out.println("O volume do cilindro é "+CalculoCilindro(raiocilindro,hcilindro));
      System.out.println("------------------------------------------ ");
    }
    if (opcao == 5){
      System.out.println("------------------------------------------ ");
      System.out.print("Digite o raio da esfera: ");
      raioesfera = leitor.nextDouble();
      System.out.println("O volume da esfera é "+CalculoEsfera(raioesfera));
      System.out.println("------------------------------------------ ");
    }
    if(opcao == 6){
      System.out.println("TCHAU :) ");
    }
  }
}