class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
  double f = 0.0;
		for(int i = 0;i <= 1998;i++){
    f += Math.floor(Math.sqrt(i));
    }
    System.out.println(f);
  }
}