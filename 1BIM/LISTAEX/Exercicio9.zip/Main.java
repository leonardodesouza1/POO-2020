import java.util.Scanner;
class Main {
  public static void main(String[] args) {
  Scanner leitor = new Scanner(System.in);
  System.out.println("Digite o x entre [-32,32");
  double x = leitor.nextDouble();
  System.out.println("Digite o y entre [-32,32");
  double y = leitor.nextDouble();
  double exp =Math.exp(-0.2 * Math.sqrt(Math.pow(x,2) + Math.pow(y,2)));
  double f = Math.pow(-200,exp);
  System.out.println(f);
  }
}