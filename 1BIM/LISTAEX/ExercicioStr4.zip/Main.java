import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Digite uma palavra\n");
    Scanner leitor = new Scanner(System.in);
    String palavra = leitor.next();
    String p = palavra.toLowerCase();
    String a = p.replace("a","1");
    p = a;
    String e = p.replace("e","2");
    p = e;
    String i = p.replace("i","3");
    p = i;
    String o = p.replace("o","4");
    p = o;
    String u = p.replace("u","5");
    p = u;
    System.out.println(p);

  }
}