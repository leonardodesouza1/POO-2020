
class Main {
  public static void main(String[] args) {
    System.out.println("Exercicio 1\n");
    double x = 15.5;
    double f = Math.cbrt(x) + Math.log(x) - Math.min(Math.tan(Math.pow(x,2)),Math.tanh(Math.pow(x,3)));
    System.out.println(f);


  }
}  