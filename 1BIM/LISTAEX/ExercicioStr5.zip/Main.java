import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Digite uma palavra\n");
    Scanner leitor = new Scanner(System.in);
    String palavra = leitor.next();
    String p = palavra.toLowerCase();
    String a = p.replace("a","");
    p = a;
    String e = p.replace("e","");
    p = e;
    String i = p.replace("i","");
    p = i;
    String o = p.replace("o","");
    p = o;
    String u = p.replace("u","");
    p = u;
    System.out.println(p);
  }
}