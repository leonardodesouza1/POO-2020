import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner leitor = new Scanner(System.in);
    String palavra = "*******";
    StringBuilder sb = new StringBuilder(palavra);
    System.out.println("JOGO DA FORCA\n");
    System.out.println("Palavra secreta: "+ palavra);
    int erros = 0;
    for(int i = 0;erros <= 3;i++){
      System.out.println("Digite uma letra: ");
      String letra = "";
      letra = leitor.next();
      if (letra.equals("a") || letra.equals("b") || letra.equals("c") || letra.equals("x") || letra.equals("i")){
        System.out.println("Voce acertou a letra");
        }else{
        System.out.println("Voce errou a letra");
        erros += 1;
        System.out.println("erros "+erros);
        }if(erros == 3){
          System.out.println("ACABOU");
          break;
        }if (letra.equals("a")){
          sb.setCharAt(0,'a');
          sb.setCharAt(2,'a');
          sb.setCharAt(4,'a');
          palavra = sb.toString();
          System.out.println(palavra);
        }if(letra.equals("b")){
        sb.setCharAt(1,'b');
        palavra = sb.toString();
        System.out.println(palavra);
        }if(letra.equals("c")){
          sb.setCharAt(3,'c');
          palavra = sb.toString();
          System.out.println(palavra);
        }if(letra.equals("x")){
          sb.setCharAt(5,'x');
          palavra = sb.toString();
          System.out.println(palavra);
        }if(letra.equals("i")){
          sb.setCharAt(6,'i');
          palavra = sb.toString();
          System.out.println(palavra);
        }if (letra.equals("abacaxi") || palavra.equals("abacaxi")){
        System.out.println("GANHOUU");
        break;
      }
        }
        }
      }
    
  
