import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner leitor = new Scanner(System.in);
    System.out.println("Diigite o x\n");
    int x = leitor.nextInt();
    System.out.println("Diigite o y\n");
    int y = leitor.nextInt();
    double f = Math.pow(Math.abs(y - 0.01*Math.pow(x,2)),1.0/100)+ Math.abs(0.01)*Math.abs(x + 10);
    System.out.println(f);
  }
}